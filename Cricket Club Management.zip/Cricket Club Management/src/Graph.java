import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class Graph extends ApplicationFrame {

    public Graph( String applicationTitle , String chartTitle ) {
        super( applicationTitle );
        JFreeChart barChart = ChartFactory.createBarChart(
                chartTitle,
                "All Format ",
                "Score",
                createDataset(),
                PlotOrientation.VERTICAL,
                true, true, false);

        ChartPanel chartPanel = new ChartPanel( barChart );
        chartPanel.setPreferredSize(new java.awt.Dimension( 560 , 367 ) );
        setContentPane( chartPanel );
    }
    private CategoryDataset createDataset () {
        final String name = " Batsman Hammad";
        final String matchplay = "Match_played";
        final String runs = "Runs";
        final String wickets = "Wickets";
        final String Hundreds = "Hundreds";
        final String fifty = "Fifty";
        final String four = "Four";
        final String sixes = "Sixes";

        final DefaultCategoryDataset dataset =
                new DefaultCategoryDataset();

        dataset.addValue(25, name, matchplay);
        dataset.addValue(200, name, runs);
        dataset.addValue(0, name, wickets);
        dataset.addValue(10, name, Hundreds);
        dataset.addValue(15, name, fifty);
        dataset.addValue(35, name, four);
        dataset.addValue(54, name, sixes);

        return dataset;}



    public static void main( String[ ] args ) {
        Graph chart = new Graph("Performance graph",
                "Player Progress");
        chart.pack( );
        RefineryUtilities.centerFrameOnScreen( chart );
        chart.setVisible( true );
    }
}