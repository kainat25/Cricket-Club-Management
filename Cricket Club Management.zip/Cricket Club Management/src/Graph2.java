import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class Graph2 extends ApplicationFrame {

    public Graph2( String applicationTitle , String chartTitle ) {
        super( applicationTitle );
        JFreeChart barChart = ChartFactory.createBarChart(
                chartTitle,
                "All format",
                "level",
                createDataset(),
                PlotOrientation.VERTICAL,
                true, true, false);

        ChartPanel chartPanel = new ChartPanel( barChart );
        chartPanel.setPreferredSize(new java.awt.Dimension( 560 , 367 ) );
        setContentPane( chartPanel );
    }

    private CategoryDataset createDataset( ) {
        final String name = " AlRounder Fahad";
        final String matchplay = "Match_played";
        final String runs = "Runs";
        final String wickets = "Wickets";
        final String Hundreds = "Hundreds";
        final String fifty = "Fifty";
        final String four = "Four";
        final String sixes = "Sixes";

        final DefaultCategoryDataset dataset =
                new DefaultCategoryDataset( );

        dataset.addValue( 200 , name , matchplay );
        dataset.addValue( 753 , name , runs);
        dataset.addValue( 59, name , wickets );
        dataset.addValue( 17 , name , Hundreds);
        dataset.addValue( 39 , name , fifty);
        dataset.addValue( 55 , name , four);
        dataset.addValue( 68 , name , sixes);

        return dataset;
    }

    public static void main( String[ ] args ) {
        Graph2 chart = new Graph2("Performance graph",
                "Player Progress");
        chart.pack( );
        RefineryUtilities.centerFrameOnScreen( chart );
        chart.setVisible( true );
    }


}

